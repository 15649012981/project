<template>
  <div class="">
  </div>
</template>

<script>
export default {
  name: 'CommonFormat',
  components: {},
  props: {
    sample: String
  },
  data () {
    return {}
  },
  computed: {},
  watch: {},
  beforeCreate () {},
  created () {},
  beforeMount () {},
  mounted () {},
  beforeUpdate () {},
  updated () {},
  activated () {},
  deactivated () {},
  beforeDestroy () {},
  destroyed () {},
  methods: {
  }
}
</script>

<style scoped>
</style>
