import GameViewOne from './GameViewOne'

export {
  GameViewOne
}
